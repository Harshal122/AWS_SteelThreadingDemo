import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visa-card',
  templateUrl: './visa-card.component.html',
  styleUrls: ['./visa-card.component.css']
})
export class VisaCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
