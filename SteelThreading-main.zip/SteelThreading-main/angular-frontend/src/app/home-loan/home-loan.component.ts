import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-loan',
  templateUrl: './home-loan.component.html',
  styleUrls: ['./home-loan.component.css']
})
export class HomeLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
