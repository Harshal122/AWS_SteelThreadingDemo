import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rupay-card',
  templateUrl: './rupay-card.component.html',
  styleUrls: ['./rupay-card.component.css']
})
export class RupayCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
