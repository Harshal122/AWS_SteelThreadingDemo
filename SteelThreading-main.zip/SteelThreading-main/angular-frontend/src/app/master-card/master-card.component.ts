import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-card',
  templateUrl: './master-card.component.html',
  styleUrls: ['./master-card.component.css']
})
export class MasterCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
