import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-loan',
  templateUrl: './personal-loan.component.html',
  styleUrls: ['./personal-loan.component.css']
})
export class PersonalLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
